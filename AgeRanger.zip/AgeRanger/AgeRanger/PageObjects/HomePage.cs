﻿using AgeRanger.Common;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgeRanger.PageObjects
{
    public class HomePage
    {
        public static void EnterName(String name)
        {

           // Driver.driver.FindElement(By.XPath("//*[@id='searchText']")).SendKeys(name);
            Driver.driver.FindElement(By.CssSelector("input[ng-model = 'searchText']")).SendKeys(name);    


        }


    }
}
