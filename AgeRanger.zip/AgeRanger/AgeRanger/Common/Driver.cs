﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgeRanger.Common
{
    public static class Driver
    {
        public static IWebDriver driver;
        public static void Initialize(String browser)
        {
            if (browser.ToLower() == "chrome")
            {
                driver = new ChromeDriver();
                driver.Url = "http://ageranger.azurewebsites.net/#/";
            }
                       
        }



      
    }
}
