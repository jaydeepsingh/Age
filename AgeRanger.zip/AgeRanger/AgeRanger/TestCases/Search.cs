﻿using AgeRanger.Common;
using AgeRanger.PageObjects;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AgeRanger.TestCases
{
    class Search
    {
        [SetUp]
        public void Initialize()
        {
            Driver.Initialize("chrome");
            Thread.Sleep(5000);
                        
        }

        [Test]
        public void SearchName()
        {
            HomePage.EnterName("Santhosh");

        }

        [TearDown]
        
        public void kill(){

            //Driver.driver.Close();
           // Driver.driver.Quit();
            
        }



}
}
